import { QuickSightClient, GenerateEmbedUrlForRegisteredUserCommand, RegisterUserCommand } from "@aws-sdk/client-quicksight";

const quicksight = new QuickSightClient({});

const AWS_ACCOUNT_ID = process.env.AWS_ACCOUNT_ID;
const DASHBOARD_ID = process.env.QUICKSIGHT_DASHBOARD_ID;
const QUICKSIGHT_NAMESPACE = "default";

async function ensureUserExists(email) {
  try {
    await quicksight.send(new RegisterUserCommand({
      AwsAccountId: AWS_ACCOUNT_ID,
      Namespace: QUICKSIGHT_NAMESPACE,
      Email: email,
      IdentityType: "QUICKSIGHT",
      UserRole: "READER",
      UserName: email
    }));
    console.log(`Created QuickSight user: ${email}`);
  } catch (error) {
    if (error.name !== "ResourceExistsException") {
      console.error("Error creating user:", error);
      throw error;
    }
    console.log(`User already exists: ${email}`);
  }
}

export async function handler(event) {
  console.log("Event:", JSON.stringify(event, null, 2));

  // Get user info from Cognito authorizer
  const claims = event.requestContext?.authorizer?.jwt?.claims;
  if (!claims) {
    return {
      statusCode: 401,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Unauthorized" })
    };
  }

  const userEmail = claims.email;
  console.log(`Generating embed URL for user: ${userEmail}`);

  try {
    // Ensure user exists in QuickSight (JIT provisioning)
    await ensureUserExists(userEmail);

    // Generate embed URL
    const command = new GenerateEmbedUrlForRegisteredUserCommand({
      AwsAccountId: AWS_ACCOUNT_ID,
      UserArn: `arn:aws:quicksight:us-east-1:${AWS_ACCOUNT_ID}:user/${QUICKSIGHT_NAMESPACE}/${userEmail}`,
      ExperienceConfiguration: {
        Dashboard: {
          InitialDashboardId: DASHBOARD_ID,
        },
      },
      SessionLifetimeInMinutes: 600,
    });

    const response = await quicksight.send(command);

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        embedUrl: response.EmbedUrl,
      }),
    };
  } catch (error) {
    console.error("Error generating embed URL:", error);
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: "Failed to generate embed URL", details: error.message }),
    };
  }
}
